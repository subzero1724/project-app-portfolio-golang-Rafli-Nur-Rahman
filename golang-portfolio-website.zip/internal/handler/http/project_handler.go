package http

import (
	"encoding/json"
	"html/template"
	"net/http"
	"portfolio/internal/dto"
	"portfolio/internal/service"
	"portfolio/internal/util"
	"strconv"

	"github.com/go-chi/chi/v5"
	"go.uber.org/zap"
)

type ProjectHandler struct {
	service   *service.ProjectService
	logger    *zap.Logger
	templates *template.Template
}

func NewProjectHandler(service *service.ProjectService, logger *zap.Logger) *ProjectHandler {
	tmpl := template.Must(template.ParseGlob("templates/*.html"))
	return &ProjectHandler{
		service:   service,
		logger:    logger,
		templates: tmpl,
	}
}

func (h *ProjectHandler) ListProjects(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	projects, err := h.service.GetAllProjects(ctx)
	if err != nil {
		h.logger.Error("Failed to get projects", zap.Error(err))
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	data := map[string]interface{}{
		"Projects": projects,
		"Title":    "Projects",
	}

	if err := h.templates.ExecuteTemplate(w, "projects.html", data); err != nil {
		h.logger.Error("Failed to execute template", zap.Error(err))
		http.Error(w, "Internal server error", http.StatusInternalServerError)
	}
}

func (h *ProjectHandler) CreateProject(w http.ResponseWriter, r *http.Request) {
	var req dto.CreateProjectRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		util.WriteError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if err := util.ValidateStruct(req); err != nil {
		util.WriteError(w, http.StatusBadRequest, err.Error())
		return
	}

	project, err := h.service.CreateProject(r.Context(), &req)
	if err != nil {
		h.logger.Error("Failed to create project", zap.Error(err))
		util.WriteError(w, http.StatusInternalServerError, "Failed to create project")
		return
	}

	util.WriteSuccess(w, http.StatusCreated, project, "Project created successfully")
}

func (h *ProjectHandler) GetProject(w http.ResponseWriter, r *http.Request) {
	idStr := chi.URLParam(r, "id")
	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		util.WriteError(w, http.StatusBadRequest, "Invalid project ID")
		return
	}

	project, err := h.service.GetProject(r.Context(), id)
	if err != nil {
		h.logger.Error("Failed to get project", zap.Error(err))
		util.WriteError(w, http.StatusNotFound, "Project not found")
		return
	}

	util.WriteSuccess(w, http.StatusOK, project, "")
}
