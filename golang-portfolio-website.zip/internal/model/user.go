package model

import "time"

type User struct {
	ID        int64     `json:"id" db:"id"`
	Name      string    `json:"name" db:"name"`
	Email     string    `json:"email" db:"email"`
	Bio       string    `json:"bio" db:"bio"`
	Title     string    `json:"title" db:"title"`
	Avatar    string    `json:"avatar" db:"avatar"`
	Github    string    `json:"github" db:"github"`
	LinkedIn  string    `json:"linkedin" db:"linkedin"`
	Twitter   string    `json:"twitter" db:"twitter"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
	UpdatedAt time.Time `json:"updated_at" db:"updated_at"`
}
