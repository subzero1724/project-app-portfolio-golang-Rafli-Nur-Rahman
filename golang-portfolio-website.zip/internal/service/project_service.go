package service

import (
	"context"
	"portfolio/internal/dto"
	"portfolio/internal/model"
	"portfolio/internal/repository"
)

type ProjectService struct {
	repo repository.ProjectRepository
}

func NewProjectService(repo repository.ProjectRepository) *ProjectService {
	return &ProjectService{repo: repo}
}

func (s *ProjectService) CreateProject(ctx context.Context, req *dto.CreateProjectRequest) (*dto.ProjectResponse, error) {
	project := &model.Project{
		Title:       req.Title,
		Description: req.Description,
		ImageURL:    req.ImageURL,
		DemoURL:     req.DemoURL,
		GithubURL:   req.GithubURL,
		Tags:        req.Tags,
		Featured:    req.Featured,
	}

	if err := s.repo.Create(ctx, project); err != nil {
		return nil, err
	}

	return s.toResponse(project), nil
}

func (s *ProjectService) GetProject(ctx context.Context, id int64) (*dto.ProjectResponse, error) {
	project, err := s.repo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}
	return s.toResponse(project), nil
}

func (s *ProjectService) GetAllProjects(ctx context.Context) ([]*dto.ProjectResponse, error) {
	projects, err := s.repo.GetAll(ctx)
	if err != nil {
		return nil, err
	}

	var responses []*dto.ProjectResponse
	for _, project := range projects {
		responses = append(responses, s.toResponse(project))
	}
	return responses, nil
}

func (s *ProjectService) GetFeaturedProjects(ctx context.Context) ([]*dto.ProjectResponse, error) {
	projects, err := s.repo.GetFeatured(ctx)
	if err != nil {
		return nil, err
	}

	var responses []*dto.ProjectResponse
	for _, project := range projects {
		responses = append(responses, s.toResponse(project))
	}
	return responses, nil
}

func (s *ProjectService) toResponse(project *model.Project) *dto.ProjectResponse {
	return &dto.ProjectResponse{
		ID:          project.ID,
		Title:       project.Title,
		Description: project.Description,
		ImageURL:    project.ImageURL,
		DemoURL:     project.DemoURL,
		GithubURL:   project.GithubURL,
		Tags:        project.Tags,
		Featured:    project.Featured,
		CreatedAt:   project.CreatedAt,
		UpdatedAt:   project.UpdatedAt,
	}
}
