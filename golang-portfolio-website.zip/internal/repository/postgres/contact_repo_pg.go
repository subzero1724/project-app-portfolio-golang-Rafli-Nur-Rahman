package postgres

import (
	"context"
	"portfolio/internal/model"

	"github.com/jackc/pgx/v5/pgxpool"
)

type ContactRepositoryPG struct {
	db *pgxpool.Pool
}

func NewContactRepository(db *pgxpool.Pool) *ContactRepositoryPG {
	return &ContactRepositoryPG{db: db}
}

func (r *ContactRepositoryPG) Create(ctx context.Context, contact *model.Contact) error {
	query := `
		INSERT INTO contacts (name, email, subject, message, status)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, created_at, updated_at
	`
	return r.db.QueryRow(ctx, query,
		contact.Name,
		contact.Email,
		contact.Subject,
		contact.Message,
		"pending",
	).Scan(&contact.ID, &contact.CreatedAt, &contact.UpdatedAt)
}

func (r *ContactRepositoryPG) GetByID(ctx context.Context, id int64) (*model.Contact, error) {
	query := `
		SELECT id, name, email, subject, message, status, created_at, updated_at
		FROM contacts WHERE id = $1
	`
	contact := &model.Contact{}
	err := r.db.QueryRow(ctx, query, id).Scan(
		&contact.ID,
		&contact.Name,
		&contact.Email,
		&contact.Subject,
		&contact.Message,
		&contact.Status,
		&contact.CreatedAt,
		&contact.UpdatedAt,
	)
	return contact, err
}

func (r *ContactRepositoryPG) GetAll(ctx context.Context) ([]*model.Contact, error) {
	query := `
		SELECT id, name, email, subject, message, status, created_at, updated_at
		FROM contacts ORDER BY created_at DESC
	`
	rows, err := r.db.Query(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var contacts []*model.Contact
	for rows.Next() {
		contact := &model.Contact{}
		err := rows.Scan(
			&contact.ID,
			&contact.Name,
			&contact.Email,
			&contact.Subject,
			&contact.Message,
			&contact.Status,
			&contact.CreatedAt,
			&contact.UpdatedAt,
		)
		if err != nil {
			return nil, err
		}
		contacts = append(contacts, contact)
	}

	return contacts, nil
}

func (r *ContactRepositoryPG) UpdateStatus(ctx context.Context, id int64, status string) error {
	query := `UPDATE contacts SET status = $1, updated_at = NOW() WHERE id = $2`
	_, err := r.db.Exec(ctx, query, status, id)
	return err
}

func (r *ContactRepositoryPG) Delete(ctx context.Context, id int64) error {
	query := `DELETE FROM contacts WHERE id = $1`
	_, err := r.db.Exec(ctx, query, id)
	return err
}
