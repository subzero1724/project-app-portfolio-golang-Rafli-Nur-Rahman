package dto

import "time"

type ProjectResponse struct {
	ID          int64     `json:"id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	ImageURL    string    `json:"image_url"`
	DemoURL     string    `json:"demo_url"`
	GithubURL   string    `json:"github_url"`
	Tags        []string  `json:"tags"`
	Featured    bool      `json:"featured"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}
