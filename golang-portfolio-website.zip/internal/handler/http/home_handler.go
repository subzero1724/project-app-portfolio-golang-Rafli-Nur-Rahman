package http

import (
	"html/template"
	"net/http"
	"portfolio/internal/service"

	"go.uber.org/zap"
)

type HomeHandler struct {
	projectService *service.ProjectService
	userService    *service.UserService
	logger         *zap.Logger
	templates      *template.Template
}

func NewHomeHandler(
	projectService *service.ProjectService,
	userService *service.UserService,
	logger *zap.Logger,
) *HomeHandler {
	tmpl := template.Must(template.ParseGlob("templates/*.html"))
	return &HomeHandler{
		projectService: projectService,
		userService:    userService,
		logger:         logger,
		templates:      tmpl,
	}
}

func (h *HomeHandler) Home(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	user, err := h.userService.GetProfile(ctx)
	if err != nil {
		h.logger.Error("Failed to get user profile", zap.Error(err))
	}

	projects, err := h.projectService.GetFeaturedProjects(ctx)
	if err != nil {
		h.logger.Error("Failed to get featured projects", zap.Error(err))
	}

	data := map[string]interface{}{
		"User":     user,
		"Projects": projects,
		"Title":    "Home",
	}

	if err := h.templates.ExecuteTemplate(w, "home.html", data); err != nil {
		h.logger.Error("Failed to execute template", zap.Error(err))
		http.Error(w, "Internal server error", http.StatusInternalServerError)
	}
}
