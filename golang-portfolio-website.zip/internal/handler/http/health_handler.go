package http

import (
	"net/http"
	"portfolio/internal/util"
)

type HealthHandler struct{}

func NewHealthHandler() *HealthHandler {
	return &HealthHandler{}
}

func (h *HealthHandler) Health(w http.ResponseWriter, r *http.Request) {
	util.WriteSuccess(w, http.StatusOK, map[string]string{
		"status": "healthy",
	}, "")
}
