# Portfolio Website - Golang

A professional portfolio website built with Golang following clean architecture principles.

## Tech Stack

- **Backend**: Go 1.21+
- **Web Framework**: chi router
- **Database**: PostgreSQL with pgx/v5 driver
- **Templates**: HTML templates
- **Styling**: Bootstrap 5
- **Logger**: Zap
- **Validation**: go-playground/validator

## Project Structure

```
project-app-portfolio-golang-rafli/
├── cmd/server/          # Application entry point
├── internal/            # Private application code
│   ├── handler/         # HTTP handlers
│   ├── service/         # Business logic
│   ├── repository/      # Data access layer
│   ├── model/           # Domain models
│   ├── dto/             # Data transfer objects
│   ├── util/            # Utilities
│   ├── config/          # Configuration
│   └── router/          # Route definitions
├── templates/           # HTML templates
├── static/              # Static assets
├── migrations/          # Database migrations
└── tests/              # Test files
```

## Setup

1. Install dependencies:
```bash
go mod download
```

2. Setup PostgreSQL database:
```bash
createdb portfolio_db
```

3. Run migrations:
```bash
psql -d portfolio_db -f migrations/001_create_users.sql
psql -d portfolio_db -f migrations/002_create_projects.sql
psql -d portfolio_db -f migrations/003_create_contacts.sql
```

4. Configure environment variables:
```bash
cp .env.example .env
# Edit .env with your database credentials
```

5. Run the application:
```bash
go run cmd/server/main.go
```

6. Visit http://localhost:8080

## Features

- Clean architecture with handler → service → repository layers
- RESTful API endpoints
- Server-side rendered HTML templates
- PostgreSQL database with pgx/v5
- Input validation
- Structured logging with Zap
- Responsive design with Bootstrap 5
- Contact form with AJAX submission
- Project showcase
- Professional design

## API Endpoints

- `GET /` - Homepage
- `GET /projects` - Projects list
- `GET /contact` - Contact form
- `POST /api/contact` - Submit contact form
- `GET /api/projects` - Get all projects (JSON)
- `POST /api/projects` - Create project (JSON)
- `GET /api/projects/{id}` - Get project by ID (JSON)
- `GET /health` - Health check

## Testing

Run tests with:
```bash
go test ./tests/... -v
```

## License

MIT License
```

```makefile file="Makefile"
.PHONY: run build test clean migrate

run:
	go run cmd/server/main.go

build:
	go build -o bin/server cmd/server/main.go

test:
	go test -v ./tests/...

clean:
	rm -rf bin/

migrate:
	psql -d portfolio_db -f migrations/001_create_users.sql
	psql -d portfolio_db -f migrations/002_create_projects.sql
	psql -d portfolio_db -f migrations/003_create_contacts.sql

deps:
	go mod download
	go mod tidy
