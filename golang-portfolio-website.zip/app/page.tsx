export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-6 lg:px-12">
        <div className="max-w-7xl w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
            {/* Left Column - Name & Navigation */}
            <div className="space-y-12">
              <div>
                <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-4">Rafli Maulana</h1>
                <p className="text-xl text-muted-foreground">Golang Developer</p>
                <p className="text-base text-muted-foreground mt-2 leading-relaxed">
                  I build scalable, high-performance backend systems with clean architecture.
                </p>
              </div>

              <nav className="space-y-6">
                <a href="#about" className="block group">
                  <div className="flex items-center gap-4">
                    <div className="h-px w-12 bg-foreground group-hover:w-20 transition-all" />
                    <span className="text-sm uppercase tracking-widest text-foreground">About</span>
                  </div>
                </a>
                <a href="#experience" className="block group">
                  <div className="flex items-center gap-4">
                    <div className="h-px w-12 bg-muted-foreground group-hover:w-20 group-hover:bg-foreground transition-all" />
                    <span className="text-sm uppercase tracking-widest text-muted-foreground group-hover:text-foreground transition-colors">
                      Experience
                    </span>
                  </div>
                </a>
                <a href="#projects" className="block group">
                  <div className="flex items-center gap-4">
                    <div className="h-px w-12 bg-muted-foreground group-hover:w-20 group-hover:bg-foreground transition-all" />
                    <span className="text-sm uppercase tracking-widest text-muted-foreground group-hover:text-foreground transition-colors">
                      Projects
                    </span>
                  </div>
                </a>
              </nav>

              {/* Social Links */}
              <div className="flex gap-6">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="GitHub"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                  </svg>
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="LinkedIn"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                  </svg>
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="Twitter"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" />
                  </svg>
                </a>
              </div>
            </div>

            {/* Right Column - About Content */}
            <div id="about" className="space-y-6 text-muted-foreground leading-relaxed">
              <p>
                I'm a developer passionate about crafting robust, scalable backend systems that power modern
                applications. My expertise lies in building clean architecture solutions with Go, ensuring
                maintainability and performance.
              </p>
              <p>
                Currently, I'm a <strong className="text-foreground">Backend Engineer</strong> at{" "}
                <a href="#" className="text-accent hover:underline">
                  TechCorp
                </a>
                , specializing in microservices architecture. I contribute to the creation and maintenance of REST APIs
                that serve millions of users, ensuring our platform meets industry best practices for security and
                scalability.
              </p>
              <p>
                In the past, I've had the opportunity to develop software across a variety of settings — from{" "}
                <strong className="text-foreground">fintech startups</strong> and{" "}
                <strong className="text-foreground">e-commerce platforms</strong> to{" "}
                <strong className="text-foreground">enterprise solutions</strong>. I've also contributed to open-source
                projects and built developer tools used by thousands.
              </p>
              <p>
                In my spare time, I'm usually exploring new technologies, contributing to open source, or writing
                technical articles about Go, distributed systems, and software architecture.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="min-h-screen flex items-center justify-center px-6 lg:px-12 py-24">
        <div className="max-w-7xl w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
            <div className="lg:sticky lg:top-24 lg:self-start">
              <h2 className="text-3xl font-bold text-foreground">Experience</h2>
            </div>

            <div className="space-y-12">
              {/* Experience Item */}
              <div className="group">
                <div className="flex gap-4 mb-4">
                  <span className="text-sm text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                    2024 — Present
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-accent transition-colors">
                    Senior Backend Engineer, Microservices · TechCorp
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    Build and maintain critical microservices used to power TechCorp's backend infrastructure. Work
                    closely with cross-functional teams, including frontend developers, product managers, and DevOps
                    engineers to implement best practices in API design, performance optimization, and system
                    reliability.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">PostgreSQL</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Redis</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Docker</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Kubernetes</span>
                  </div>
                </div>
              </div>

              {/* Experience Item */}
              <div className="group">
                <div className="flex gap-4 mb-4">
                  <span className="text-sm text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                    2022 — 2024
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-accent transition-colors">
                    Backend Engineer · StartupX
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    Developed RESTful APIs and microservices for a fintech platform serving over 100K users. Implemented
                    authentication systems, payment integrations, and real-time notification services. Reduced API
                    response times by 40% through optimization and caching strategies.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">MySQL</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">MongoDB</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">AWS</span>
                  </div>
                </div>
              </div>

              {/* Experience Item */}
              <div className="group">
                <div className="flex gap-4 mb-4">
                  <span className="text-sm text-muted-foreground uppercase tracking-widest whitespace-nowrap">
                    2020 — 2022
                  </span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:text-accent transition-colors">
                    Software Engineer · Enterprise Solutions Inc
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    Built and maintained enterprise-level web applications using Go and modern backend frameworks.
                    Collaborated with QA teams to ensure code quality and implemented comprehensive testing strategies
                    achieving 85% code coverage.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">PostgreSQL</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">REST API</span>
                    <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Microservices</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="min-h-screen flex items-center justify-center px-6 lg:px-12 py-24">
        <div className="max-w-7xl w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
            <div className="lg:sticky lg:top-24 lg:self-start">
              <h2 className="text-3xl font-bold text-foreground">Projects</h2>
            </div>

            <div className="space-y-12">
              {/* Project Item */}
              <a href="#" className="group block">
                <div className="relative">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2 group-hover:text-accent transition-colors">
                        E-Commerce REST API
                        <svg
                          className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </h3>
                      <p className="text-muted-foreground leading-relaxed mb-4">
                        A complete REST API for an e-commerce platform with user authentication, product management,
                        shopping cart, order processing, and payment integration. Built with clean architecture
                        principles and comprehensive test coverage.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Chi Router</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">PostgreSQL</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">JWT</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Stripe</span>
                      </div>
                    </div>
                  </div>
                </div>
              </a>

              {/* Project Item */}
              <a href="#" className="group block">
                <div className="relative">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2 group-hover:text-accent transition-colors">
                        Real-Time Chat Service
                        <svg
                          className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </h3>
                      <p className="text-muted-foreground leading-relaxed mb-4">
                        Scalable real-time messaging service using WebSockets and Redis pub/sub. Supports private
                        messaging, group chats, typing indicators, and message history with 99.9% uptime.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">WebSocket</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Redis</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">MongoDB</span>
                      </div>
                    </div>
                  </div>
                </div>
              </a>

              {/* Project Item */}
              <a href="#" className="group block">
                <div className="relative">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2 group-hover:text-accent transition-colors">
                        Task Management API
                        <svg
                          className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </h3>
                      <p className="text-muted-foreground leading-relaxed mb-4">
                        RESTful API for project and task management with role-based access control, file uploads,
                        activity logging, and email notifications. Implemented with repository pattern and dependency
                        injection.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Gin</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">PostgreSQL</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">AWS S3</span>
                      </div>
                    </div>
                  </div>
                </div>
              </a>

              {/* Project Item */}
              <a href="#" className="group block">
                <div className="relative">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2 group-hover:text-accent transition-colors">
                        Microservices Architecture
                        <svg
                          className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                          />
                        </svg>
                      </h3>
                      <p className="text-muted-foreground leading-relaxed mb-4">
                        Demonstrated microservices architecture with API gateway, service discovery, distributed
                        tracing, and centralized logging. Deployed on Kubernetes with CI/CD pipeline for automated
                        testing and deployment.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Go</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">gRPC</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Docker</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Kubernetes</span>
                        <span className="px-3 py-1 text-xs rounded-full bg-accent/10 text-accent">Jaeger</span>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="min-h-screen flex items-center justify-center px-6 lg:px-12 py-24">
        <div className="max-w-3xl w-full">
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl font-bold text-foreground">Get In Touch</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                If you would like to discuss a project or just say hi, I'm always down to chat.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Email</h3>
                <a href="mailto:rafli@example.com" className="text-accent hover:underline">
                  rafli@example.com
                </a>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">LinkedIn</h3>
                <a
                  href="https://linkedin.com/in/raflimaulana"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  @raflimaulana
                </a>
              </div>

              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">GitHub</h3>
                <a
                  href="https://github.com/raflimaulana"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:underline"
                >
                  @raflimaulana
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">© 2025. Crafted by Rafli Maulana.</p>
            <div className="flex gap-6">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Imprint
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
