package http

import (
	"encoding/json"
	"html/template"
	"net/http"
	"portfolio/internal/dto"
	"portfolio/internal/service"
	"portfolio/internal/util"

	"go.uber.org/zap"
)

type ContactHandler struct {
	service   *service.ContactService
	logger    *zap.Logger
	templates *template.Template
}

func NewContactHandler(service *service.ContactService, logger *zap.Logger) *ContactHandler {
	tmpl := template.Must(template.ParseGlob("templates/*.html"))
	return &ContactHandler{
		service:   service,
		logger:    logger,
		templates: tmpl,
	}
}

func (h *ContactHandler) ShowContactForm(w http.ResponseWriter, r *http.Request) {
	data := map[string]interface{}{
		"Title": "Contact",
	}

	if err := h.templates.ExecuteTemplate(w, "contact.html", data); err != nil {
		h.logger.Error("Failed to execute template", zap.Error(err))
		http.Error(w, "Internal server error", http.StatusInternalServerError)
	}
}

func (h *ContactHandler) SubmitContact(w http.ResponseWriter, r *http.Request) {
	var req dto.CreateContactRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		util.WriteError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if err := util.ValidateStruct(req); err != nil {
		util.WriteError(w, http.StatusBadRequest, err.Error())
		return
	}

	contact, err := h.service.CreateContact(r.Context(), &req)
	if err != nil {
		h.logger.Error("Failed to create contact", zap.Error(err))
		util.WriteError(w, http.StatusInternalServerError, "Failed to submit contact form")
		return
	}

	util.WriteSuccess(w, http.StatusCreated, contact, "Contact form submitted successfully")
}
